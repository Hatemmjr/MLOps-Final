"""
Data validation tests (Component 5 — CI/CD data validation stage).
Uses pandera to validate schema and data quality.
"""

import numpy as np
import pandas as pd
import pandera as pa
import pytest
from pandera import Column, DataFrameSchema, Check


# ─── Schema definition ────────────────────────────────────────────────────────
TELCO_SCHEMA = DataFrameSchema(
    {
        "tenure": Column(float, Check.greater_than_or_equal_to(0)),
        "MonthlyCharges": Column(
            float, Check.in_range(0, 200), nullable=False
        ),
        "TotalCharges": Column(float, nullable=True),
        "gender": Column(str, Check.isin(["Male", "Female"])),
        "Contract": Column(
            str,
            Check.isin(["Month-to-month", "One year", "Two year"]),
        ),
        "Churn": Column(int, Check.isin([0, 1])),
    },
    coerce=True,
)


def _make_valid_df(n: int = 50) -> pd.DataFrame:
    rng = np.random.default_rng(42)
    return pd.DataFrame(
        {
            "tenure": rng.integers(0, 72, n).astype(float),
            "MonthlyCharges": rng.uniform(18, 120, n),
            "TotalCharges": rng.uniform(18, 8000, n),
            "gender": rng.choice(["Male", "Female"], n),
            "Contract": rng.choice(
                ["Month-to-month", "One year", "Two year"], n
            ),
            "Churn": rng.choice([0, 1], n),
        }
    )


def test_valid_dataframe_passes_schema():
    df = _make_valid_df()
    TELCO_SCHEMA.validate(df)  # must not raise


def test_negative_tenure_fails_schema():
    df = _make_valid_df()
    df.loc[0, "tenure"] = -1.0
    with pytest.raises(pa.errors.SchemaError):
        TELCO_SCHEMA.validate(df)


def test_invalid_gender_fails_schema():
    df = _make_valid_df()
    df.loc[0, "gender"] = "Unknown"
    with pytest.raises(pa.errors.SchemaError):
        TELCO_SCHEMA.validate(df)


def test_invalid_churn_value_fails_schema():
    df = _make_valid_df()
    df.loc[0, "Churn"] = 2
    with pytest.raises(pa.errors.SchemaError):
        TELCO_SCHEMA.validate(df)


def test_target_class_balance_is_acceptable():
    """Churn rate for the synthetic dataset should be between 10% and 60%."""
    df = _make_valid_df(1000)
    churn_rate = df["Churn"].mean()
    assert 0.10 <= churn_rate <= 0.60, f"Unexpected churn rate: {churn_rate:.2f}"
