# Notebooks

This directory contains EDA (Exploratory Data Analysis) notebooks only.
No pipeline logic lives here — all pipeline code is in `src/`.

## Contents
- `eda.ipynb` — Exploratory analysis of the Telco Churn dataset
